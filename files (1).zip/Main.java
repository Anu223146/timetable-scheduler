import java.util.*;

/**
 * TimetableScheduler — BYOP Capstone Project
 * Automatically generates conflict-free academic timetables
 * using a Genetic Algorithm.
 *
 * Author : [Your Name]
 * Course : Programming in Java
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("+===========================================+");
        System.out.println("|      TIMETABLE SCHEDULER  v1.0           |");
        System.out.println("|      Java BYOP -- Capstone Project        |");
        System.out.println("+===========================================+");
        System.out.println();

        // ── Seed data ──────────────────────────────────────────────
        List<Subject>  subjects  = DataSeeder.createSubjects();
        List<Teacher>  teachers  = DataSeeder.createTeachers(subjects);
        List<Room>     rooms     = DataSeeder.createRooms();
        List<TimeSlot> timeSlots = DataSeeder.createTimeSlots();

        System.out.println("Subjects  : " + subjects.size());
        System.out.println("Teachers  : " + teachers.size());
        System.out.println("Rooms     : " + rooms.size());
        System.out.println("TimeSlots : " + timeSlots.size());
        System.out.println();

        // ── Schedule ───────────────────────────────────────────────
        Scheduler scheduler = new GeneticScheduler(subjects, teachers, rooms, timeSlots);
        System.out.println("Running Genetic Algorithm...");
        System.out.println();

        Timetable timetable = scheduler.generate();

        // ── Display ────────────────────────────────────────────────
        TimetableUI ui = new TimetableUI();
        ui.display(timetable);

        // ── Conflict Report ────────────────────────────────────────
        System.out.println("\n--------------------------------------------------------");
        System.out.println("  CONFLICT REPORT");
        System.out.println("--------------------------------------------------------");
        ConflictDetector.printReport(timetable);

        // ── Summary ────────────────────────────────────────────────
        System.out.println("\n--------------------------------------------------------");
        System.out.printf("  Total entries  : %d%n", timetable.size());
        System.out.printf("  Conflicts      : %d%n", timetable.countConflicts());
        System.out.printf("  Fitness score  : %.4f%n", timetable.fitnessScore());
        System.out.println("--------------------------------------------------------");
        System.out.println("  Timetable generation complete.");

        // ── Optional CSV export ────────────────────────────────────
        try {
            TimetableExporter.exportCSV(timetable, "timetable.csv");
        } catch (Exception e) {
            System.out.println("CSV export failed: " + e.getMessage());
        }
    }
}
