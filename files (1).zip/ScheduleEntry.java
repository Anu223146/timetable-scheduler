/**
 * One entry in the generated timetable:
 * a (Subject, Teacher, Room, TimeSlot) tuple.
 */
public class ScheduleEntry {
    private final Subject  subject;
    private final Teacher  teacher;
    private final Room     room;
    private final TimeSlot timeSlot;

    public ScheduleEntry(Subject subject, Teacher teacher, Room room, TimeSlot timeSlot) {
        this.subject  = subject;
        this.teacher  = teacher;
        this.room     = room;
        this.timeSlot = timeSlot;
    }

    public Subject  getSubject()  { return subject; }
    public Teacher  getTeacher()  { return teacher; }
    public Room     getRoom()     { return room; }
    public TimeSlot getTimeSlot() { return timeSlot; }

    /**
     * Two entries conflict if they share the same slot AND
     * the same teacher OR the same room.
     */
    public boolean conflictsWith(ScheduleEntry other) {
        if (!this.timeSlot.getId().equals(other.timeSlot.getId())) return false;
        return this.teacher.getId().equals(other.teacher.getId())
            || this.room.getId().equals(other.room.getId());
    }

    @Override
    public String toString() {
        return String.format("%-28s | %-20s | %-12s | %s",
            subject.getName(), teacher.getName(), room.getName(), timeSlot);
    }
}
