/**
 * Represents a classroom or lab.
 */
public class Room {
    private final String  id;
    private final String  name;
    private final int     capacity;
    private final boolean isLab;

    public Room(String id, String name, int capacity, boolean isLab) {
        this.id       = id;
        this.name     = name;
        this.capacity = capacity;
        this.isLab    = isLab;
    }

    public String  getId()       { return id; }
    public String  getName()     { return name; }
    public int     getCapacity() { return capacity; }
    public boolean isLab()       { return isLab; }

    @Override
    public String toString() {
        return String.format("%s (%s, cap=%d)", name, isLab ? "Lab" : "Class", capacity);
    }
}
