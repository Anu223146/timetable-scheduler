/**
 * Represents a discrete time slot in the weekly schedule.
 * e.g., Monday 09:00–10:00
 */
public class TimeSlot {
    private final String id;
    private final String day;
    private final String startTime;
    private final String endTime;
    private final int    period;

    public TimeSlot(String id, String day, int period, String startTime, String endTime) {
        this.id        = id;
        this.day       = day;
        this.period    = period;
        this.startTime = startTime;
        this.endTime   = endTime;
    }

    public String getId()        { return id; }
    public String getDay()       { return day; }
    public String getStartTime() { return startTime; }
    public String getEndTime()   { return endTime; }
    public int    getPeriod()    { return period; }

    @Override
    public String toString() {
        return String.format("%s P%d (%s-%s)", day, period, startTime, endTime);
    }
}
