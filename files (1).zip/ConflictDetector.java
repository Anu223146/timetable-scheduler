import java.util.*;

/**
 * Scans a Timetable and returns a detailed list of all conflicts.
 */
public class ConflictDetector {

    public enum ConflictType {
        TEACHER_DOUBLE_BOOKED,
        ROOM_DOUBLE_BOOKED,
        TEACHER_UNAVAILABLE
    }

    // Simple conflict holder (no record keyword — works on Java 8+)
    public static class Conflict {
        public final ConflictType  type;
        public final ScheduleEntry entry1;
        public final ScheduleEntry entry2; // may be null
        public final String        description;

        public Conflict(ConflictType type, ScheduleEntry entry1,
                        ScheduleEntry entry2, String description) {
            this.type        = type;
            this.entry1      = entry1;
            this.entry2      = entry2;
            this.description = description;
        }
    }

    public static List<Conflict> detect(Timetable timetable) {
        List<Conflict>      conflicts = new ArrayList<>();
        List<ScheduleEntry> entries   = timetable.getEntries();

        for (int i = 0; i < entries.size(); i++) {
            for (int j = i + 1; j < entries.size(); j++) {
                ScheduleEntry a = entries.get(i);
                ScheduleEntry b = entries.get(j);

                if (!a.getTimeSlot().getId().equals(b.getTimeSlot().getId())) continue;

                if (a.getTeacher().getId().equals(b.getTeacher().getId())) {
                    conflicts.add(new Conflict(
                        ConflictType.TEACHER_DOUBLE_BOOKED, a, b,
                        String.format("Teacher %s double-booked: '%s' and '%s' at %s",
                            a.getTeacher().getName(),
                            a.getSubject().getName(), b.getSubject().getName(),
                            a.getTimeSlot())
                    ));
                }

                if (a.getRoom().getId().equals(b.getRoom().getId())) {
                    conflicts.add(new Conflict(
                        ConflictType.ROOM_DOUBLE_BOOKED, a, b,
                        String.format("Room %s double-booked: '%s' and '%s' at %s",
                            a.getRoom().getName(),
                            a.getSubject().getName(), b.getSubject().getName(),
                            a.getTimeSlot())
                    ));
                }
            }

            ScheduleEntry e = entries.get(i);
            if (!e.getTeacher().isAvailable(e.getTimeSlot().getId())) {
                conflicts.add(new Conflict(
                    ConflictType.TEACHER_UNAVAILABLE, e, null,
                    String.format("Teacher %s unavailable at %s",
                        e.getTeacher().getName(), e.getTimeSlot())
                ));
            }
        }
        return conflicts;
    }

    public static void printReport(Timetable timetable) {
        List<Conflict> conflicts = detect(timetable);
        if (conflicts.isEmpty()) {
            System.out.println("No conflicts detected. Timetable is valid!");
            return;
        }
        System.out.printf("%d conflict(s) found:%n", conflicts.size());
        for (Conflict c : conflicts) {
            System.out.println("  [" + c.type + "] " + c.description);
        }
    }
}
