import java.util.*;

/**
 * Renders the timetable as formatted tables to the console.
 */
public class TimetableUI {

    private static final String SEPARATOR =
        "+" + "-".repeat(12) + "+" + ("-".repeat(22) + "+").repeat(6);

    public void display(Timetable timetable) {
        System.out.println("\n========================================================");
        System.out.println("                   WEEKLY TIMETABLE                    ");
        System.out.println("========================================================\n");

        String[] dayOrder = {"MON", "TUE", "WED", "THU", "FRI"};

        Map<String, List<ScheduleEntry>> byDay = new LinkedHashMap<>();
        for (String d : dayOrder) byDay.put(d, new ArrayList<>());

        for (ScheduleEntry e : timetable.getEntries()) {
            String d = e.getTimeSlot().getDay();
            if (byDay.containsKey(d)) byDay.get(d).add(e);
        }

        for (Map.Entry<String, List<ScheduleEntry>> dayEntry : byDay.entrySet()) {
            printDayTable(dayEntry.getKey(), dayEntry.getValue());
        }

        // Full list
        System.out.println("\n--------------------------------------------------------");
        System.out.println("  FULL SCHEDULE ENTRIES");
        System.out.println("--------------------------------------------------------");
        System.out.printf("  %-28s | %-20s | %-12s | %s%n",
                "SUBJECT", "TEACHER", "ROOM", "SLOT");
        System.out.println("  " + "-".repeat(80));
        for (ScheduleEntry e : timetable.getEntries()) {
            System.out.println("  " + e);
        }
    }

    private void printDayTable(String day, List<ScheduleEntry> entries) {
        System.out.println("  >> " + fullDayName(day));
        System.out.println(SEPARATOR);
        System.out.printf("| %-10s |", "Room");
        for (int p = 1; p <= 6; p++) System.out.printf(" %-20s |", "Period " + p);
        System.out.println();
        System.out.println(SEPARATOR);

        // Group by room name
        Map<String, Map<Integer, ScheduleEntry>> roomMap = new LinkedHashMap<>();
        for (ScheduleEntry e : entries) {
            String roomName = e.getRoom().getName();
            if (!roomMap.containsKey(roomName)) roomMap.put(roomName, new TreeMap<>());
            roomMap.get(roomName).put(e.getTimeSlot().getPeriod(), e);
        }

        if (roomMap.isEmpty()) {
            System.out.printf("| %-10s |%s%n", "--", "                      |".repeat(6));
        }

        for (Map.Entry<String, Map<Integer, ScheduleEntry>> row : roomMap.entrySet()) {
            System.out.printf("| %-10s |", abbr(row.getKey(), 10));
            Map<Integer, ScheduleEntry> periods = row.getValue();
            for (int p = 1; p <= 6; p++) {
                ScheduleEntry e = periods.get(p);
                String cell = "";
                if (e != null) {
                    String code    = e.getSubject().getCode();
                    String teacher = e.getTeacher().getName().split(" ")[e.getTeacher().getName().split(" ").length - 1];
                    cell = code + "/" + teacher;
                }
                System.out.printf(" %-20s |", abbr(cell, 20));
            }
            System.out.println();
        }
        System.out.println(SEPARATOR);
        System.out.println();
    }

    private String fullDayName(String abbr) {
        switch (abbr) {
            case "MON": return "Monday";
            case "TUE": return "Tuesday";
            case "WED": return "Wednesday";
            case "THU": return "Thursday";
            case "FRI": return "Friday";
            default:    return abbr;
        }
    }

    private String abbr(String s, int max) {
        if (s == null || s.isEmpty()) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + ".";
    }
}
