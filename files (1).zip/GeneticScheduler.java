import java.util.*;

/**
 * Implements a Genetic Algorithm to produce a conflict-free weekly timetable.
 *
 * Algorithm:
 *  1. Create POPULATION_SIZE random timetables (chromosomes).
 *  2. Evaluate each by FITNESS = 1 / (1 + conflicts).
 *  3. SELECT parents via tournament selection.
 *  4. CROSSOVER parents to produce offspring.
 *  5. MUTATE offspring randomly.
 *  6. Repeat for GENERATIONS or until a perfect schedule is found.
 */
public class GeneticScheduler implements Scheduler {

    // ── GA parameters ──────────────────────────────────────────────
    private static final int    POPULATION_SIZE = 100;
    private static final int    GENERATIONS     = 500;
    private static final double MUTATION_RATE   = 0.05;
    private static final int    TOURNAMENT_SIZE = 5;

    // ── Problem data ───────────────────────────────────────────────
    private final List<Subject>  subjects;
    private final List<Teacher>  teachers;
    private final List<Room>     rooms;
    private final List<TimeSlot> timeSlots;
    private final Random         rng = new Random(42);

    public GeneticScheduler(List<Subject> subjects, List<Teacher> teachers,
                            List<Room> rooms, List<TimeSlot> timeSlots) {
        this.subjects  = subjects;
        this.teachers  = teachers;
        this.rooms     = rooms;
        this.timeSlots = timeSlots;
    }

    // ── Public API ─────────────────────────────────────────────────

    @Override
    public Timetable generate() {
        List<Timetable> population = initPopulation();
        Timetable best = getBest(population);

        System.out.printf("   Gen %4d  |  fitness=%.4f  conflicts=%d%n",
                0, best.fitnessScore(), best.countConflicts());

        for (int gen = 1; gen <= GENERATIONS; gen++) {
            population = evolve(population);
            Timetable candidate = getBest(population);
            if (candidate.fitnessScore() > best.fitnessScore()) {
                best = candidate;
            }
            if (gen % 50 == 0) {
                System.out.printf("   Gen %4d  |  fitness=%.4f  conflicts=%d%n",
                        gen, best.fitnessScore(), best.countConflicts());
            }
            if (best.countConflicts() == 0) {
                System.out.printf("   Perfect schedule found at generation %d!%n", gen);
                break;
            }
        }
        return best;
    }

    // ── Initialisation ─────────────────────────────────────────────

    private List<Timetable> initPopulation() {
        List<Timetable> pop = new ArrayList<>();
        for (int i = 0; i < POPULATION_SIZE; i++) {
            pop.add(randomTimetable());
        }
        return pop;
    }

    private Timetable randomTimetable() {
        Timetable t = new Timetable();
        for (Subject subject : subjects) {
            for (int h = 0; h < subject.getHoursPerWeek(); h++) {
                Teacher  teacher = randomTeacherFor(subject);
                Room     room    = randomRoomFor(subject);
                TimeSlot slot    = randomSlot();
                t.addEntry(new ScheduleEntry(subject, teacher, room, slot));
            }
        }
        return t;
    }

    // ── Evolution ──────────────────────────────────────────────────

    private List<Timetable> evolve(List<Timetable> population) {
        List<Timetable> next = new ArrayList<>();
        next.add(getBest(population));   // elitism: keep best unchanged
        while (next.size() < POPULATION_SIZE) {
            Timetable parent1 = tournamentSelect(population);
            Timetable parent2 = tournamentSelect(population);
            Timetable child   = mutateCopy(crossover(parent1, parent2));
            next.add(child);
        }
        return next;
    }

    // ── Selection ──────────────────────────────────────────────────

    private Timetable tournamentSelect(List<Timetable> population) {
        Timetable best = null;
        for (int i = 0; i < TOURNAMENT_SIZE; i++) {
            Timetable candidate = population.get(rng.nextInt(population.size()));
            if (best == null || candidate.fitnessScore() > best.fitnessScore()) {
                best = candidate;
            }
        }
        return best;
    }

    // ── Crossover ──────────────────────────────────────────────────

    private Timetable crossover(Timetable p1, Timetable p2) {
        List<ScheduleEntry> e1 = p1.getEntries();
        List<ScheduleEntry> e2 = p2.getEntries();
        int cut = rng.nextInt(Math.min(e1.size(), e2.size()));
        Timetable child = new Timetable();
        for (int i = 0; i < e1.size(); i++) {
            child.addEntry(i < cut ? e1.get(i) : e2.get(Math.min(i, e2.size() - 1)));
        }
        return child;
    }

    // ── Mutation ───────────────────────────────────────────────────

    private Timetable mutateCopy(Timetable t) {
        Timetable mutated = new Timetable();
        for (ScheduleEntry entry : t.getEntries()) {
            if (rng.nextDouble() < MUTATION_RATE) {
                Subject  subject = entry.getSubject();
                Teacher  teacher = rng.nextBoolean() ? entry.getTeacher() : randomTeacherFor(subject);
                Room     room    = rng.nextBoolean() ? entry.getRoom()    : randomRoomFor(subject);
                TimeSlot slot    = rng.nextBoolean() ? entry.getTimeSlot(): randomSlot();
                mutated.addEntry(new ScheduleEntry(subject, teacher, room, slot));
            } else {
                mutated.addEntry(entry);
            }
        }
        return mutated;
    }

    // ── Helpers ────────────────────────────────────────────────────

    private Timetable getBest(List<Timetable> population) {
        Timetable best = population.get(0);
        for (Timetable t : population) {
            if (t.fitnessScore() > best.fitnessScore()) best = t;
        }
        return best;
    }

    private Teacher randomTeacherFor(Subject subject) {
        List<Teacher> capable = new ArrayList<>();
        for (Teacher t : teachers)
            if (t.canTeach(subject.getId())) capable.add(t);
        if (capable.isEmpty()) return teachers.get(rng.nextInt(teachers.size()));
        return capable.get(rng.nextInt(capable.size()));
    }

    private Room randomRoomFor(Subject subject) {
        List<Room> suitable = new ArrayList<>();
        for (Room r : rooms)
            if (subject.needsLab() == r.isLab()) suitable.add(r);
        if (suitable.isEmpty()) return rooms.get(rng.nextInt(rooms.size()));
        return suitable.get(rng.nextInt(suitable.size()));
    }

    private TimeSlot randomSlot() {
        return timeSlots.get(rng.nextInt(timeSlots.size()));
    }
}
