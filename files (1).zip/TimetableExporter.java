import java.io.*;
import java.util.*;

/**
 * Exports the timetable to a CSV file (Excel-compatible).
 */
public class TimetableExporter {

    public static void exportCSV(Timetable timetable, String filePath) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {
            pw.println("Day,Period,StartTime,EndTime,Subject,SubjectCode,Teacher,Room,RoomType");

            Map<String, Integer> dayOrder = new LinkedHashMap<>();
            dayOrder.put("MON", 1); dayOrder.put("TUE", 2);
            dayOrder.put("WED", 3); dayOrder.put("THU", 4); dayOrder.put("FRI", 5);

            List<ScheduleEntry> sorted = new ArrayList<>(timetable.getEntries());
            Collections.sort(sorted, new Comparator<ScheduleEntry>() {
                @Override
                public int compare(ScheduleEntry a, ScheduleEntry b) {
                    int dayA = dayOrder.getOrDefault(a.getTimeSlot().getDay(), 99);
                    int dayB = dayOrder.getOrDefault(b.getTimeSlot().getDay(), 99);
                    if (dayA != dayB) return Integer.compare(dayA, dayB);
                    return Integer.compare(a.getTimeSlot().getPeriod(), b.getTimeSlot().getPeriod());
                }
            });

            for (ScheduleEntry e : sorted) {
                TimeSlot ts = e.getTimeSlot();
                pw.printf("%s,%d,%s,%s,%s,%s,%s,%s,%s%n",
                    ts.getDay(),
                    ts.getPeriod(),
                    ts.getStartTime(),
                    ts.getEndTime(),
                    csvEscape(e.getSubject().getName()),
                    e.getSubject().getCode(),
                    csvEscape(e.getTeacher().getName()),
                    csvEscape(e.getRoom().getName()),
                    e.getRoom().isLab() ? "Lab" : "Classroom"
                );
            }
        }
        System.out.println("Timetable exported to: " + filePath);
    }

    private static String csvEscape(String s) {
        if (s.contains(",") || s.contains("\"")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }
}
