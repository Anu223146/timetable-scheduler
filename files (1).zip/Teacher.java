import java.util.*;

/**
 * Represents a teacher/faculty member.
 */
public class Teacher {
    private final String       id;
    private final String       name;
    private final List<String> subjectIds;
    private final Set<String>  unavailableSlotIds;

    public Teacher(String id, String name, List<String> subjectIds) {
        this.id                 = id;
        this.name               = name;
        this.subjectIds         = new ArrayList<>(subjectIds);
        this.unavailableSlotIds = new HashSet<>();
    }

    public void blockSlot(String slotId) { unavailableSlotIds.add(slotId); }

    public boolean canTeach(String subjectId) { return subjectIds.contains(subjectId); }
    public boolean isAvailable(String slotId) { return !unavailableSlotIds.contains(slotId); }

    public String       getId()         { return id; }
    public String       getName()       { return name; }
    public List<String> getSubjectIds() { return Collections.unmodifiableList(subjectIds); }

    @Override
    public String toString() { return name; }
}
