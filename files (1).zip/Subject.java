/**
 * Represents an academic subject/course.
 */
public class Subject {
    private final String id;
    private final String name;
    private final String code;
    private final int hoursPerWeek;
    private final boolean needsLab;

    public Subject(String id, String name, String code, int hoursPerWeek, boolean needsLab) {
        this.id           = id;
        this.name         = name;
        this.code         = code;
        this.hoursPerWeek = hoursPerWeek;
        this.needsLab     = needsLab;
    }

    public String  getId()           { return id; }
    public String  getName()         { return name; }
    public String  getCode()         { return code; }
    public int     getHoursPerWeek() { return hoursPerWeek; }
    public boolean needsLab()        { return needsLab; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%d h/wk)", code, name, hoursPerWeek);
    }
}
