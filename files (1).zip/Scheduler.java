/**
 * Strategy interface for timetable generation algorithms.
 */
public interface Scheduler {
    Timetable generate();
}
