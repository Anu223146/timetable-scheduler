import java.util.*;

/**
 * Holds all ScheduleEntry objects that form one complete timetable.
 * Provides conflict counting and fitness scoring for the genetic algorithm.
 */
public class Timetable {
    private final List<ScheduleEntry> entries = new ArrayList<>();

    public void addEntry(ScheduleEntry entry) {
        entries.add(entry);
    }

    public List<ScheduleEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    /** Count all pairwise conflicts among entries. */
    public int countConflicts() {
        int conflicts = 0;
        for (int i = 0; i < entries.size(); i++) {
            for (int j = i + 1; j < entries.size(); j++) {
                if (entries.get(i).conflictsWith(entries.get(j))) {
                    conflicts++;
                }
            }
        }
        return conflicts;
    }

    /**
     * Fitness = 1 / (1 + conflicts).
     * 1.0 means a perfect, conflict-free timetable.
     */
    public double fitnessScore() {
        return 1.0 / (1.0 + countConflicts());
    }

    public int size() {
        return entries.size();
    }
}
