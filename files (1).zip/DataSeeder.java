import java.util.*;

/**
 * Provides seed data: subjects, teachers, rooms, and time slots
 * for a typical Computer Science semester.
 */
public class DataSeeder {

    public static List<Subject> createSubjects() {
        List<Subject> list = new ArrayList<>();
        list.add(new Subject("S1",  "Data Structures & Algorithms", "CS201", 4, false));
        list.add(new Subject("S2",  "Object-Oriented Programming",  "CS202", 4, false));
        list.add(new Subject("S3",  "Database Management Systems",  "CS301", 3, false));
        list.add(new Subject("S4",  "Operating Systems",            "CS302", 3, false));
        list.add(new Subject("S5",  "Computer Networks",            "CS401", 3, false));
        list.add(new Subject("S6",  "Software Engineering",         "CS402", 2, false));
        list.add(new Subject("S7",  "Programming Lab (Java)",       "CS203", 2, true));
        list.add(new Subject("S8",  "DBMS Lab",                     "CS303", 2, true));
        list.add(new Subject("S9",  "Mathematics III",              "MA301", 4, false));
        list.add(new Subject("S10", "Discrete Mathematics",         "MA201", 3, false));
        return list;
    }

    public static List<Teacher> createTeachers(List<Subject> subjects) {
        List<Teacher> teachers = new ArrayList<>();

        teachers.add(new Teacher("T1", "Prof. Anita Sharma",  Arrays.asList("S1", "S2", "S7")));
        teachers.add(new Teacher("T2", "Dr. Ramesh Gupta",    Arrays.asList("S3", "S8")));
        teachers.add(new Teacher("T3", "Prof. Meena Joshi",   Arrays.asList("S4", "S5")));
        teachers.add(new Teacher("T4", "Dr. Suresh Patel",    Arrays.asList("S6", "S2")));
        teachers.add(new Teacher("T5", "Prof. Kavita Singh",  Arrays.asList("S9", "S10")));
        teachers.add(new Teacher("T6", "Dr. Amit Verma",      Arrays.asList("S1", "S4", "S5")));
        teachers.add(new Teacher("T7", "Prof. Lakshmi Iyer",  Arrays.asList("S7", "S8", "S3")));

        // Block Monday Period-1 for Dr. Gupta
        teachers.get(1).blockSlot("MON-1");

        return teachers;
    }

    public static List<Room> createRooms() {
        List<Room> list = new ArrayList<>();
        list.add(new Room("R1", "Room 101",    60,  false));
        list.add(new Room("R2", "Room 102",    60,  false));
        list.add(new Room("R3", "Room 201",    80,  false));
        list.add(new Room("R4", "Room 202",    80,  false));
        list.add(new Room("R5", "Seminar Hall",120, false));
        list.add(new Room("L1", "Lab A",       40,  true));
        list.add(new Room("L2", "Lab B",       40,  true));
        list.add(new Room("L3", "Lab C",       35,  true));
        return list;
    }

    public static List<TimeSlot> createTimeSlots() {
        List<TimeSlot> slots = new ArrayList<>();
        String[] days   = {"MON", "TUE", "WED", "THU", "FRI"};
        String[] starts = {"09:00", "10:00", "11:00", "12:00", "13:00", "14:00"};
        String[] ends   = {"10:00", "11:00", "12:00", "13:00", "14:00", "15:00"};

        for (String day : days) {
            for (int p = 0; p < starts.length; p++) {
                String id = day + "-" + (p + 1);
                slots.add(new TimeSlot(id, day, p + 1, starts[p], ends[p]));
            }
        }
        return slots;
    }
}
